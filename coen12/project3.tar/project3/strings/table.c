#include <stdio.h>
#include <stdlib.h>
#include "set.h"
#include <assert.h>
#include <string.h>
#include <stdbool.h>

#define EMPTY 0
#define FILLED 1
#define DELETED 2

typedef struct set
{
    int count;
    int length;
    char **data;
    int *flags; //{Filled, Empty,  Deleted}
} SET;

int search(SET *sp, void *elt, bool *found);
SET *createSet(int maxElts);
void destroySet(SET *sp);
int numElements(SET *sp);
void addElement(SET *sp, char *elt);
void removeElement(SET *sp, char *elt);
char *findElement(SET *sp, char *elt);
char **getElements(SET *sp);

/**
 * Encrpyts a string through a hashing algorithm
 */
// O(n)
unsigned strhash(char *s)
{
    // printf("Hash\n");
    unsigned hash = 0;
    while (*s != '\0')
        hash = 31 * hash + *s++;
    return hash;
}

/**
 * Searches the hashmap for a specified value "elt" through hashing
 * sp: set searched from
 * elt: value searched for
 * found: boolean marker for if found
 */
int search(SET *sp, void *elt, bool *found)
{
    // printf("Search\n");
    assert(sp != NULL);
    assert(elt != NULL);    

    int i;
    int avaliable = -1;
    int index;
    unsigned hash = strhash(elt) % sp->length;
    *found = false;
    for (i = 0; i < sp->length; i++)
    {
        index = (hash + i) % sp->length;

        if (sp->flags[index] == FILLED)
        {
            if (strcmp(elt, sp->data[index]) == 0)
            {
                *found = true;
                return index;
            }
        }
        else if (sp->flags[index] == EMPTY)
        {
            return avaliable == -1 ? index : avaliable;
        }
        else if (sp->flags[index] == DELETED)
        {
            if (avaliable == -1)
                avaliable = index;
        }
    }
    *found = false;
    return avaliable;
}
/**
    Creates a hashtable given the max capacity of maxElts
*/
// O(n)
SET *createSet(int maxElts)
{
    // printf("Create\n");
  assert(maxElts != 0);
    SET *sp;
    sp = malloc(sizeof(SET));
    sp->count = 0;
    sp->length = maxElts;
    sp->data = malloc(sizeof(char *) * maxElts);
    sp->flags = malloc(sizeof(int) * maxElts);
    assert(sp->data != NULL);
    assert(sp->flags != NULL);

    int i;
    for (i = 0; i < sp->length; i++)
    {
        sp->flags[i] = EMPTY;
    }
    return sp;
}

/**
 * Adds an element to a hashtable given the value
 */
// O(n)
void addElement(SET *sp, char *elt)
{
    // printf("Add\n");
    assert(sp != NULL);
    assert(elt != NULL);
    bool found;
    int index = search(sp, elt, &found);
    if (!found)
    {
        assert(sp->count < sp->length);
        assert(strdup(elt) != NULL);
        sp->data[index] = strdup(elt);
        sp->flags[index] = FILLED;
        sp->count++;
    }
}

/**
 * Frees the given set in memory
 */
// O(n)
void destroySet(SET *sp)
{
    // printf("Destroy\n");
    assert(sp != NULL);
    int i;
    for (i = 0; i < sp->length; i++)
    {
        if (sp->flags[i] == FILLED)
            free(sp->data[i]);
    }
    free(sp->data);
    free(sp->flags);
    free(sp);
}

// returns number of elements in the set
// O(n)
int numElements(SET *sp)
{
    // printf("Num\n");
    assert(sp != NULL);
    return sp->count;
}

/**
 * removes an element from the set
 */
// O(n)
void removeElement(SET *sp, char *elt)
{
    // printf("Remove\n");
    assert(sp != NULL);
    assert(elt != NULL);
    bool found;
    int index = search(sp, elt, &found);
    if (found)
    {
        free(sp->data[index]);
        sp->flags[index] = DELETED;
        sp->count--;
    }
}

/**
 * If elt is in the given set, return the matching element else return NULL
 */
// O(n)
char *findElement(SET *sp, char *elt)
{
    // printf("Find\n");
    bool found = false;
    int index = search(sp, elt, &found);
    if (found == false)
        return NULL;
    return sp->data[index];
}

/**
 * Allocate and return an array of elements in the set pointed to by sp
 */
// O(n)
char **getElements(SET *sp)
{
    // printf("Get\n");
    assert(sp != NULL);;
    char **elts;
    int i, j;

    assert(sp != NULL);

    elts = malloc(sizeof(char *) * sp->count);
    assert(elts != NULL);
    for (i = 0, j = 0; i < sp->length; i++)
        if (sp->flags[i] == FILLED)
            elts[j++] = sp->data[i];
    return elts;
}
